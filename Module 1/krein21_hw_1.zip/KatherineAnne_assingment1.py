# CS521 Assignment 1 - <Katherine>

my_int = 4 + 3 * 3
my_int += 5
print(my_int)
